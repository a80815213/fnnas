/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * YS-A99 / fnOS 6.18: wrapper to avoid duplicate enum/typedef definitions
 * between <linux/rockchip/rockchip_sip.h> and this legacy soc header.
 * Original saved as rockchip_sip.h.bak-ys-a99
 */
#ifndef __SOC_ROCKCHIP_SIP_H
#define __SOC_ROCKCHIP_SIP_H
#include <linux/rockchip/rockchip_sip.h>
#endif
