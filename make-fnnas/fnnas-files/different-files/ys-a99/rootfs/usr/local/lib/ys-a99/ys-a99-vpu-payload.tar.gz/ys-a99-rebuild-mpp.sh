#!/bin/bash
# YS-A99 / ZM-A399SE (RK3399) -- 系统 OTA 换内核后恢复 H.265/VP9/4K 硬解
# 飞牛官方 rk_vcodec.ko 未开 CONFIG_CPU_RK3399，新内核的模块会缺 RKVDEC 匹配。
# 本脚本用 /usr/local/src/ys-a99-mpp 里的源码针对当前内核现场重编并热重载。
#   sudo ys-a99-rebuild-mpp.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "请用 sudo 运行"; exit 1; }

KVER="$(uname -r)"
SRC=/usr/local/src/ys-a99-mpp
KDIR="/usr/src/linux-headers-$KVER"
KO="/lib/modules/$KVER/updates/trim/rk_vcodec/rk_vcodec.ko"

[ -d "$KDIR" ] || { echo "缺少内核头文件 $KDIR（等系统更新装上 linux-headers-$KVER 再跑）"; exit 1; }
[ -d "$SRC/mpp" ] || { echo "缺少源码 $SRC/mpp"; exit 1; }
command -v make >/dev/null || { echo "缺少 make"; exit 1; }

echo ">> 内核 $KVER，补 vendor 头文件"
mkdir -p "$KDIR/include/linux/rockchip" "$KDIR/include/uapi/linux" "$KDIR/include/soc/rockchip"
cp -f "$SRC/headers/linux/dma-buf-cache.h"            "$KDIR/include/linux/"
cp -f "$SRC/headers/linux/rockchip/rockchip_sip.h"    "$KDIR/include/linux/rockchip/"
cp -f "$SRC/headers/soc/rockchip/rockchip_opp_select.h" "$KDIR/include/soc/rockchip/"
cp -f "$SRC/headers/uapi/linux/rk-mpp.h"              "$KDIR/include/uapi/linux/"
SIPH="$KDIR/include/soc/rockchip/rockchip_sip.h"
[ -f "$SIPH.bak-ys-a99" ] || cp -a "$SIPH" "$SIPH.bak-ys-a99" 2>/dev/null || true
cat > "$SIPH" <<'EOF'
#ifndef __SOC_ROCKCHIP_SIP_H
#define __SOC_ROCKCHIP_SIP_H
#include <linux/rockchip/rockchip_sip.h>
#endif
EOF

echo ">> 编译 rk_vcodec.ko"
cd "$SRC" && bash build.sh > /tmp/ys-a99-mpp-build.log 2>&1 || { tail -40 /tmp/ys-a99-mpp-build.log; exit 1; }
NEWKO="$SRC/build/rk_vcodec.ko"
[ -f "$NEWKO" ] || { echo "未产出 $NEWKO"; exit 1; }
VM="$(modinfo -F vermagic "$NEWKO")"
case "$VM" in *"$KVER"*) ;; *) echo "vermagic 不匹配: $VM != $KVER"; exit 1;; esac

echo ">> 备份并安装（原模块 -> /boot/ys-a99-rk_vcodec.ko.bak-$KVER）"
mkdir -p "$(dirname "$KO")"
[ -f "/boot/ys-a99-rk_vcodec.ko.bak-$KVER" ] || cp -a "$KO" "/boot/ys-a99-rk_vcodec.ko.bak-$KVER" 2>/dev/null || true
systemctl stop mediasrv 2>/dev/null || true
pkill -x ffmpeg 2>/dev/null || true
sleep 1
cp -f "$NEWKO" "$KO" && chmod 644 "$KO"
depmod -a 2>/dev/null || true
if ! rmmod rk_vcodec 2>/dev/null; then
    echo "热卸载失败，模块文件已装好，请重启：sudo reboot"; exit 0
fi
insmod "$KO" || { echo "insmod 失败，回滚"; cp -f "/boot/ys-a99-rk_vcodec.ko.bak-$KVER" "$KO"; insmod "$KO"; }
systemctl start mediasrv 2>/dev/null || true
sleep 2
echo ">> MPP 版本: $(cat /proc/mpp_service/version 2>/dev/null || echo 未加载)"
echo ">> 支持设备:"; cat /proc/mpp_service/supports-device 2>/dev/null | grep DEVICE
echo ">> 若看到 DEVICE[ 9]:RKVDEC 即恢复成功"
