#!/bin/bash
# YS-A99 / ZM-A399SE  VPU dtb 切换与回退（只改 /boot/armbianEnv.txt，改完需重启）
#   sudo ys-a99-dtb.sh mpp      -> 启用 rk3399-ys-a99-mpp-rga.dtb（vendor MPP/RGA 版）
#   sudo ys-a99-dtb.sh orig     -> 恢复原始 rk3399-ys-a99.dtb
#   sudo ys-a99-dtb.sh status   -> 查看当前设置
set -e
ENV=/boot/armbianEnv.txt
BAK=/boot/armbianEnv.txt.bak-ys-a99
NEW=rockchip/rk3399-ys-a99-mpp-rga.dtb
OLD=rockchip/rk3399-ys-a99.dtb
[ "$(id -u)" -eq 0 ] || { echo "请用 sudo 运行"; exit 1; }

case "${1:-status}" in
    mpp)
        [ -f "/boot/dtb/rockchip/rk3399-ys-a99-mpp-rga.dtb" ] || { echo "缺 dtb：/boot/dtb/rockchip/rk3399-ys-a99-mpp-rga.dtb"; exit 1; }
        [ -f "$BAK" ] || cp -a "$ENV" "$BAK"
        sed -i "s|^fdtfile=.*|fdtfile=$NEW|" "$ENV"
        echo "已切换到 $NEW（重启生效）"; grep '^fdtfile=' "$ENV"
        echo "回退： sudo ys-a99-dtb.sh orig && sudo reboot"
        ;;
    orig)
        sed -i "s|^fdtfile=.*|fdtfile=$OLD|" "$ENV"
        echo "已恢复 $OLD（重启生效）"; grep '^fdtfile=' "$ENV"
        ;;
    status)
        echo "当前 armbianEnv.txt:"; grep '^fdtfile=' "$ENV"
        echo "启动中的 dtb:"; cat /proc/device-tree/model 2>/dev/null; echo
        echo "可用 dtb:"; ls -l /boot/dtb/rockchip/rk3399-ys-a99*.dtb
        [ -f "$BAK" ] && { echo "备份:"; grep '^fdtfile=' "$BAK"; }
        ;;
    *) echo "用法: $0 {mpp|orig|status}"; exit 1 ;;
esac
