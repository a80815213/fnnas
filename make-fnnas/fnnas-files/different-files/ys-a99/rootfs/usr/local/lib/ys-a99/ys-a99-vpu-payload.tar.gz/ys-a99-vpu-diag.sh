#!/usr/bin/env bash
# YS-A99 / ZM-A399SE (RK3399, Rock Pi 4C compatible) -- fnOS VPU / RKMPP diagnosis  v2
# READ-ONLY. Does not modify the system. Run as root:
#     sudo bash ys-a99-vpu-diag.sh 2>&1 | tee vpu-diag.txt
#
# v2 context (2026-11): fnOS officially supports Firefly-RK3399 (ARM 1.2.0701), and the
# community project K2O2/am40-fnos-fixes proved RK3399 hardware transcoding works on the
# fnOS mainline kernel. Four root causes, in order:
#   1) DTB rga@ff680000 uses mainline "rockchip,rk3399-rga", but fnOS ships only vendor
#      rga3.ko which matches "rockchip,rga2"/"rga3*" -> no /dev/rga -> mediasrv SEGV.
#   2) DTB lacks vendor MPP nodes (mpp-srv / vepu / vdpu / rkvdec) -> nothing binds.
#   3) fnOS rk_vcodec.ko was built WITHOUT CONFIG_CPU_RK3399 -> no HEVC/VP9/4K decoder.
#   4) mediasrv requests AV1 decode / HEVC encode that RK3399 does not have -> shim needed.
# NOTE: upstream warns fnOS 1.2.0701 cannot build/port the VPU driver directly.
#
# This script decides which of the above still applies to YOUR running system.

set +e
KVER="$(uname -r)"
MODROOTS="/lib/modules/$KVER /usr/lib/modules/$KVER"
sec() { printf '\n====================================================================\n== %s\n====================================================================\n' "$1"; }
run() { printf '\n$ %s\n' "$*"; eval "$@" 2>&1 | head -120; }

sec "0. Identity / clock / boot config"
run "date"
run "uname -a"
run "cat /etc/os-release | head -8"
run "cat /proc/cmdline"
run "cat /boot/armbianEnv.txt 2>/dev/null || cat /boot/fnEnv.txt 2>/dev/null"
run "mount | grep -E ' on /dev | on /sys '"

sec "1. DECISIVE A -- does the running kernel ship the vendor MPP / RGA modules?"
run "ls -d /lib/modules/* /usr/lib/modules/* 2>&1"
run "find $MODROOTS -type f \\( -name 'rk_vcodec*.ko*' -o -name 'rga[23]*.ko*' -o -name '*mpp*.ko*' -o -name '*vpu*.ko*' \\) 2>&1"
run "ls -lR $MODROOTS/updates 2>/dev/null | head -80"
run "grep -iE 'rk_vcodec|rga3|rga2|mpp' $MODROOTS/modules.dep 2>&1 | head -40"
run "find / -xdev -type f \\( -name 'rk_vcodec*.ko*' -o -name 'rga3*.ko*' \\) 2>/dev/null | head -30"

KO="$(find $MODROOTS /boot /usr/lib -type f -name 'rk_vcodec.ko*' 2>/dev/null | head -1)"
printf '\n[detected rk_vcodec.ko] %s\n' "${KO:-(NOT FOUND)}"
if [ -n "$KO" ]; then
    run "modinfo -F vermagic '$KO' 2>&1"
    run "strings '$KO' | grep -oE 'rockchip,rkv-decoder-[a-z0-9-]+' | sort -u"
    run "strings '$KO' | grep -oE 'rockchip,(vpu|rkv|mpp)[a-z0-9-]*' | sort -u | head -40"
    run "strings '$KO' | grep -oE 'custom-rk3399[^ ]*|MPP_VERSION[^ ]*' | head -10"
fi
RGAKO="$(find $MODROOTS /usr/lib -type f -name 'rga3.ko*' 2>/dev/null | head -1)"
printf '\n[detected rga3.ko] %s\n' "${RGAKO:-(NOT FOUND)}"
if [ -n "$RGAKO" ]; then
    run "modinfo -F vermagic '$RGAKO' 2>&1"
    run "strings '$RGAKO' | grep -oE 'rockchip,rga[0-9a-z_]*' | sort -u"
fi

sec "2. DECISIVE B -- current DTB: RGA compatible + MPP nodes present?"
printf '\n-- /proc/device-tree/rga@ff680000/compatible: '; tr '\0' '|' < /proc/device-tree/rga@ff680000/compatible 2>/dev/null || printf '(missing)'; printf '\n'
printf '   EXPECT after fix: rockchip,rga2\n'
for n in $(find /proc/device-tree -maxdepth 1 \( -name '*vpu*' -o -name '*vdec*' -o -name '*vepu*' -o -name '*vdpu*' -o -name '*rkvdec*' -o -name '*mpp*' -o -name '*rga*' -o -name '*gpu*' -o -name 'iommu@ff65*' -o -name 'iommu@ff66*' \) 2>/dev/null | sort); do
    printf '\n-- %s\n' "$n"
    printf '   compatible: '; tr '\0' '|' < "$n/compatible" 2>/dev/null; printf '\n'
    printf '   status    : '; tr '\0' '|' < "$n/status" 2>/dev/null || printf '(absent = enabled by default)'; printf '\n'
done
run "ls /proc/device-tree/ | grep -Ei 'vpu|vdec|rga|mpp|gpu|codec'"

sec "3. Device nodes + real platform-driver bindings"
run "ls -l --time-style=full-iso /dev/mpp_service /dev/rga /dev/vpu_service /dev/rkvdec /dev/video* /dev/dri/* 2>&1"
run "ls -l /sys/class/video4linux/ /sys/class/drm/ 2>&1"
run "cat /sys/class/video4linux/video0/name 2>&1"
run "readlink -f /sys/class/video4linux/video0/device 2>&1"
for drv in mpp_vepu2 mpp_vdpu2 mpp_rkvdec rga2 rga3; do
    printf '\n-- /sys/bus/platform/drivers/%s : ' "$drv"
    ls /sys/bus/platform/drivers/$drv/ 2>/dev/null | grep -vE '^(module|bind|unbind|uevent)$' | tr '\n' ' '
    printf '\n'
done
run "ls -l /proc/mpp_service/ 2>&1"
run "cat /proc/mpp_service/version /proc/mpp_service/supports-device 2>&1"

sec "4. Loaded modules"
run "lsmod"
run "lsmod | grep -Ei 'mpp|vpu|vdec|venc|rkv|rga|hantro|panfrost|mali|rockchip|videobuf|v4l2|drm'"

sec "5. Kernel log (root required -- dmesg failed without sudo before)"
run "dmesg -T 2>&1 | grep -Ei 'mpp|vpu|vdec|venc|rkv|rga|hantro|panfrost|mali|drm|iommu|video|mediasrv' | tail -100"
run "journalctl -k --no-pager -n 4000 2>/dev/null | grep -Ei 'mpp|vpu|vdec|rkv|rga|hantro|drm' | tail -60"

sec "6. fnOS userspace: mediasrv crashes? vendor libs present?"
run "systemctl status mediasrv --no-pager -l 2>&1 | head -40"
run "journalctl -u mediasrv --no-pager -n 60 2>&1 | tail -60"
run "ls -l /usr/lib/*/librockchip_mpp* /usr/lib/*/librga* /usr/lib/*/libmpp* 2>&1 | head -40"
run "ls -l /etc/udev/rules.d/*mpp* /lib/udev/rules.d/*mpp* 2>&1"
run "ps aux | grep -Ei 'mediasrv|ffmpeg' | grep -v grep | head -20"

sec "7. Kernel config (mainline codec drivers)"
if [ -f /proc/config.gz ]; then
    run "zcat /proc/config.gz | grep -E 'CONFIG_(VIDEO_(HANTRO|ROCKCHIP|DEV)|DRM_(PANFROST|ROCKCHIP|LIMA)|ROCKCHIP_(RGA|IOMMU)|V4L2_MEM2MEM|MODVERSIONS)'"
elif [ -f "/boot/config-$KVER" ]; then
    run "grep -E 'CONFIG_(VIDEO_(HANTRO|ROCKCHIP|DEV)|DRM_(PANFROST|ROCKCHIP|LIMA)|ROCKCHIP_(RGA|IOMMU)|V4L2_MEM2MEM|MODVERSIONS)' /boot/config-$KVER"
else
    printf '  (no /proc/config.gz and no /boot/config-%s)\n' "$KVER"
fi
run "ls -d /usr/src/linux-headers-* 2>&1"

sec "8. AUTO VERDICT"
printf 'kernel        : %s\n' "$KVER"
if [ -z "$KO" ]; then
    echo ">> NO rk_vcodec.ko  => dtb alone CANNOT work. Need an fnOS base image that ships the"
    echo "   vendor MPP stack (e.g. official 1.2.0302-based Firefly/AM40 image), rebuilt for YS-A99."
else
    echo ">> rk_vcodec.ko found: $KO"
    if strings "$KO" 2>/dev/null | grep -q 'rockchip,rkv-decoder-rk3399'; then
        echo "   + has RK3399 rkvdec match -> only dtb + mediasrv shim + udev rules are needed."
    else
        echo "   - MISSING rk3399 rkvdec match (built without CONFIG_CPU_RK3399)"
        echo "     -> rebuild the module from K2O2/am40-fnos-fixes kernel-mpp/ against THIS kernel."
    fi
fi
if [ -z "$RGAKO" ]; then
    echo ">> NO rga3.ko -> /dev/rga will stay missing; check /usr/lib/modules and fnOS image version."
else
    echo ">> rga3.ko found: $RGAKO  (dtb MUST say compatible=rockchip,rga2)"
fi
RGA_COMPAT="$(tr '\0' '|' < /proc/device-tree/rga@ff680000/compatible 2>/dev/null)"
echo ">> live dtb rga compatible = ${RGA_COMPAT:-(missing)}"
if [ -d /proc/device-tree/mpp-srv ]; then echo ">> live dtb HAS mpp-srv"; else echo ">> live dtb has NO mpp-srv -> switch to rk3399-ys-a99-mpp-rga.dtb"; fi

sec "DONE -- paste the whole vpu-diag.txt back"
